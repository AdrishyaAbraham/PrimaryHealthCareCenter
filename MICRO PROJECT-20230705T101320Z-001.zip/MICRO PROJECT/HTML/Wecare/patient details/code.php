<?php
session_start();
require 'dbcon.php';

if(isset($_POST['save_patient']))
{
    $name= mysqli_real_escape_string($con,$_POST['pname']);
    $address= mysqli_real_escape_string($con,$_POST['address']);
    $phone= mysqli_real_escape_string($con,$_POST['phone']);
    $bloodgrp= mysqli_real_escape_string($con,$_POST['bldgrp']);
    $insulin= mysqli_real_escape_string($con,$_POST['insulin']);
    $medcon= mysqli_real_escape_string($con,$_POST['medcon']);


    $query="INSERT into patients(name,email,phone,course) values('$name','$address','$phone','$bloodgrp','$insulin','$medcon')";
    
    $query_run=mysqli_query($con,$query);
    if($query_run)
    {
        $_SESSION['message']="Updated Succesfully";
        header("Location:patient_update.php");
        exit(0);
    }
    else{
        $_SESSION['message']="Not Updated Succesfully";
        header("Location:patient_update.php");
        exit(0);
    }
}




?>